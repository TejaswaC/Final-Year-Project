# -*- coding: utf-8 -*-
"""
Created on Mon Jan 22 19:05:51 2018

@author: Tejaswa
"""
import os
import requests

os.chdir('e:\\')
import requests
from bs4 import BeautifulSoup
 
url = 'https://www.coingecko.com/en/price_charts/bitcoin/inr'
    
page = requests.get(url)
page.content
soup = BeautifulSoup(page.content,'html.parser')
    
name_box = soup.find('div',attrs={'class':'coin-value'})
    
    
name = name_box.text.strip()
    
name
    
price = name
    
price = price[1:11]
price
import csv
from datetime import datetime
    
with open('Bitcoin.csv','a') as csv_file:
    writer = csv.writer(csv_file)
    writer.writerow([price,datetime.now()])
   
    
   
